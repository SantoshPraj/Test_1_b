public class FirstNonRepeatingCharacter {
    public static int firstUniqChar(String s) {
        int[] charCount = new int[26]; // Array to store the frequency of each character

        // Iterate through the string to count the frequency of each character
        for (char c : s.toCharArray()) {
            charCount[c - 'a']++;
        }

        // Iterate through the string to find the first non-repeating character
        for (int i = 0; i < s.length(); i++) {
            if (charCount[s.charAt(i) - 'a'] == 1) {
                return i;
            }
        }

        // If no non-repeating character is found, return -1
        return -1;
    }

    public static void main(String[] args) {
        String s = "aabb";
        int index = firstUniqChar(s);
        System.out.println("Index of the first non-repeating character: " + index);
    }
}
